'use strict';

import  React,{Component} from 'react';
import Locations from './Locations';


export  default  class  AppContainer extends Component{
    constructor(props){
        super(props);
        this.state={
            locations:[
                {
                  name:'Sigiriya',
                  description:"An ancinent rock fortress located in the northern Matale District near the town of Dambulla in the Central Province, Sri Lanka."
                }, {
                    name:'Polonaruwa',
                   description:"It is the main town of Polonnaruwa District in North Central Province, Sri Lanka. Kaduruwela area is the Polonnaruwa New Town and the other part of Polonnaruwa remains as the royal ancient city of the Kingdom of Polonnaruwa."
                },{
                    name:'Anuradaphura',
                    description:"It is the first ancient capital of Sri Lanka which lasted for the longest period as the capital in the country.It is important to locals for religion, history, and the culture and world-famous for its well preserved ruins of the Great Sri Lankan Civilization."
                }
            ]

        }
    }

    render() {
        return <div>
            <h2>Tourist locations</h2>
            <Locations locations={this.state.locations}/>

        </div>;
    }
}