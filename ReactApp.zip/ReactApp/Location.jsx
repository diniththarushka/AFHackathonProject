import React from  'react';

const Location= props =>{
    const {location}=props;
    return <table>
        <tr align="center">
            <td align="center">{location.name}</td>
            <td align="center">{location.description}</td>
        </tr>
    </table>
};

export  default Location;