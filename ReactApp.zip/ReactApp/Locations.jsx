import React,{Component} from 'react';
import PropTypes from 'prop-types';

import Location from './Location.jsx';

export  default class  Locations extends Component{
    static  get propTypes(){
        return{
            locations:PropTypes.array
        }
    }
    constructor(props){
        super(props);
    }
    render(){
        const {locations}=this.props;
        return <div>
            <table>
                <thead>
                <tr>
                    <th>Names</th>
                    <th>Description</th>
                </tr>
                </thead>
                <td>
                {
                    locations.map(location => {
                        return <Location key={location.name} location={location}/>
                    })
                }
                </td>
           </table>
        </div>
    }
}